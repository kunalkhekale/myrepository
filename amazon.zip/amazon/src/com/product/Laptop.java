package com.product;

public class Laptop extends Product {
	private String ram;
	private String storage;
	private String battery;
	private String processor;
	private String displaySize;

	

	public Laptop(String productName, double productOrignalPrice, int discountPer, String colour,
			String productCategory, String ram, String storage, String battery, String processor,
			String displaySize) {
		super(productName, productOrignalPrice, discountPer, colour, productCategory);
		this.ram = ram;
		this.storage = storage;
		this.battery = battery;
		this.processor = processor;
		this.displaySize = displaySize;
	}

	public void displayLaptopInformation() {
		System.out.println("Laptop Name : " + getProductName());
		System.out.println("Laptop Clour :  " + getColour());
		System.out.println("Laptop Ram : " + getRam() + "GB");
		System.out.println("Laptop Storage : " + getStorage() + "GB");
		System.out.println("Laptop Battery : " + getBattery() + "mah");
		System.out.println("Laptop processor :" + getProcessor());
		System.out.println("Laptop DisplaySize :" + getDisplaySize()+"Inches");
		System.out.println("M.R.P:" + getProductOrignalPrice());
		System.out.println("discount :" + getDiscountPer() + "%");
		 System.out.println("selling price :"+getSellingPrice());
	}

	public String getRam() {
		return ram;
	}

	public void setRam(String ram) {
		this.ram = ram;
	}

	public String getStorage() {
		return storage;
	}

	public void setStorage(String storage) {
		this.storage = storage;
	}

	public String getBattery() {
		return battery;
	}

	public void setBattery(String battery) {
		this.battery = battery;
	}

	public String getProcessor() {
		return processor;
	}

	public void setProcessor(String processor) {
		this.processor = processor;
	}

	public String getDisplaySize() {
		return displaySize;
	}

	public void setDisplaySize(String displaySize) {
		this.displaySize = displaySize;
	}

	@Override
	public String toString() {
		return "Laptop [ram=" + ram + ", storage=" + storage + ", battery=" + battery + ", processor=" + processor
				+ ", displaySize=" + displaySize + "]";
	}

}
