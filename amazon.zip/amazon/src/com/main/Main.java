package com.main;

import com.makeproduct.MakeProduct1;
import com.makeproduct.MakeProduct2;
import com.product.Laptop;
import com.product.Mobile;

public class Main {

	public static void main(String[] args) {
		Mobile device1 = MakeProduct1.createFirstProdut();
		device1.displayMobileInformation();

		System.out.println();
		System.out.println();

		Mobile device2 = MakeProduct1.createsecondProdut();
		device2.displayMobileInformation();

		System.out.println();
		System.out.println();

		Mobile device3 = MakeProduct1.createthirdProdut();
		device3.displayMobileInformation();

		System.out.println("**************************************************");
		
		
		Laptop FirstProduct = MakeProduct2.FirstProduct();
		FirstProduct.displayLaptopInformation();
		
		System.out.println();
		System.out.println();
		
		Laptop SecondProduct=MakeProduct2.SecondProduct();
		SecondProduct.displayLaptopInformation();
	}
	
}
