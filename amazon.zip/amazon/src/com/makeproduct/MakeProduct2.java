package com.makeproduct;

import com.product.Laptop;

public class MakeProduct2 {

	public static Laptop FirstProduct() {
		Laptop Laptop = new Laptop("HP", 99999, 74, "Black", "Laptop", "8", "256", "1 lithium ion batteries required",
				"Athlon Silver", "15.6");
		return Laptop;

	}

	public static Laptop SecondProduct() {
		Laptop Laptop = new Laptop("HP", 150000, 65, "Red", "Laptop", "8", "256", "1 lithium ion batteries required",
				"Athlon Silver", "20.6");
		return Laptop;
	}
}
