package com.makeproduct;

import com.product.Mobile;

public class MakeProduct1 {
       
	public static Mobile createFirstProdut() {
		Mobile redmi = new Mobile ("Redmi k20 pro", 31999, 35, "carbon black", "Mobile", "8","128" ,"6000" );
		return redmi;
		
	}
	public static Mobile createsecondProdut() {
		Mobile redmi = new Mobile ("Redmi k20", 20000, 32, "fire red", "Mobile", "6","128" ,"4000" );
		return redmi;
}
	public static Mobile createthirdProdut() {
		Mobile redmi = new Mobile ("Redmi 12", 15000, 30, "yellow", "Mobile", "4","64" ,"3500" );
		return redmi;
}
}
