package com.product;

public class Product {
       private String productName ;
       
       private int discountPer ;
       private String colour ;
       private String productCategory ;
       private double SellingPrice ;
   
       private double productOrginalPrice;
       
       
       public Product(String productName, double productOrignalPrice, int discountPer, String colour,
			String productCategory) {
		super();
		this.productName = productName;
		this.productOrginalPrice = productOrignalPrice;
		this.discountPer = discountPer;
		this.colour = colour;
		this.productCategory = productCategory;
	    this.SellingPrice = CalculateSellingPrice() ;
	     
		
	}

	public Product() {
		super();
	
	}
	private double  CalculateSellingPrice () {
		double discount = productOrginalPrice * discountPer / 100 ;
		SellingPrice = productOrginalPrice - discount ;
		return SellingPrice ;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getProductOrignalPrice() {
		return productOrginalPrice;
	}

	public void setProductOrignalPrice(double productOrignalPrice) {
		this.productOrginalPrice = productOrignalPrice;
	}

	public int getDiscountPer() {
		return discountPer;
	}

	public void setDiscountPer(int discountPer) {
		this.discountPer = discountPer;
	}


	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductType(String productCategory) {
		this.productCategory = productCategory;
	}
	

	public double getSellingPrice() {
		return SellingPrice;
	}

	public void setSellingPrice(int sellingPrice) {
		SellingPrice = sellingPrice;
	}

	@Override
	public String toString() {
		return "Product [productName=" + productName + ", productOrignalPrice=" + productOrginalPrice + ", discountPer="
				+ discountPer + ", colour=" + colour + ", productCategory=" + productCategory + ", SellingPrice="
				+ SellingPrice + "]";
	}

	
	
}
